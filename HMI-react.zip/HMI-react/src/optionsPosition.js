var options = {
    "group": {
        imgX: [0,0,57],
        imgY: [0,0,32],,
        txtX: [0,0,75],,
        txtY: [0,0,80],,
        plus: [0,0,0],
        minus: [0,0,0]
    },
    "unit": {
        imgX: [0,0,25],
        imgY: [0,0,105],,
        txtX: [0,0,68],,
        txtY: [0,0,131],,
        plus: [0,0,0],
        minus: [0,0,0]
    },
    "shift": {
        imgX: [0,0,82],
        imgY: [0,0,162],,
        txtX: [0,0,98],,
        txtY: [0,0,162],,
        plus: [0,0,0],
        minus: [0,0,0]
    }
};

module.exports = favourite;