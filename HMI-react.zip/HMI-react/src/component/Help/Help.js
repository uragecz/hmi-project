/**
 * Created by urunzl on 2.12.2016.
 */
//components
import React,{Component} from 'react';
//const phantom = require('phantom');


//styles, images
import './Help.css'
import printOne from '../../../assets/printOne.png';
import printAll from '../../../assets/printAll.png';
import information from '../../../assets/information.png';

class Help extends Component {
    constructor(props){
        super(props);
        this.pageClick = this.pageClick.bind(this);
    }
    render() {
        return (
            <div id="helpPage" className="opacityBoxMenu">
                <form method="POST" encType="multipart/form-data" action="saveImage.php" id="phpSendForm">
                    <div className="helpItem" onClick={this.printOnePage.bind(this)}>
                        <img src={printOne} width={100} height={100}/>
                    </div>
                    <div className="helpItem">
                        <img src={printAll} width={100} height={100}/>
                    </div>
                    <div className="helpItem">
                        <img src={information} width={100} height={100}/>
                    </div>
                    <input type="hidden" name="img_val" id="img_val" value="" />
                </form>
            </div>
        )
    }

    componentDidMount() {
        window.addEventListener('click', this.pageClick, false)
    }

    componentWillUnmount(){
        window.removeEventListener('click', this.pageClick, false)
    }

    pageClick(e) {
        console.log('page');
        if (e.target.id === 'helpPage') {
            this.closePage();
        }
    }

    closePage(){
        this.props.closeHelpPage();
    }

    printOnePage(){
        let page = document.getElementById('appContainer');
        document.getElementById('helpPage').style.display= 'none';
         phantom.create().then(function(ph) {
            ph.createPage().then(function(page) {
                page.open('https://stackoverflow.com/').then(function(status) {
                    console.log(status);
                    page.property('content').then(function(content) {
                        console.log(content);
                        page.close();
                        ph.exit();
                    });
                });
            });
         });
        document.getElementById('helpPage').style.display= '';
    }
}

export default Help;