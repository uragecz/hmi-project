/**
 * Created by urunzl on 7.10.2016.
 */
var historyConstants = {
    ADD_LINK: "ADD_LINK",
};

module.exports = historyConstants;