/**
 * Created by urunzl on 4.10.2016.
 */

var selectionConstants = {
    SWITCH_GROUP: "SWITCH_GROUP",
    SWITCH_UNIT: "SWITCH_UNIT",
    SWITCH_SHIFT: "SWITCH_SHIFT",
    SET_SHIFTS: "SET_SHIFTS",
    SET_GROUPS: "SET_GROUPS"
};

module.exports = selectionConstants;