/**
 * Created by urunzl on 8.2.2017.
 */
var faultReportConstants = {
    SET_CUTS: "SET_CUTS",
    SET_Q_ALARMS: "SET_Q_ALARMS",
    SET_Y_ALARMS: "SET_Y_ALARMS",
    SET_TECH_ALARMS: "SET_TECH_ALARMS",
    SET_QUALITY_VALUES: "SET_QUALITY_VALUES"
};

module.exports = faultReportConstants;