/**
 * Created by urunzl on 24.1.2017.
 */
var loginConstants = {
    LOGIN: "LOGIN",
    LOGOUT: "LOGOUT"
};

module.exports = loginConstants;