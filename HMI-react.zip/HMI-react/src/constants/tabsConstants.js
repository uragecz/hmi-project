/**
 * Created by urunzl on 24.11.2016.
 */
var tabsConstants = {
    ADD_TAB: "ADD_TAB",
    CLOSE_TAB: "CLOSE_TAB",
    CHANGE_TAB: "CHANGE_TAB",
    CHANGE_ACTIVE_TAB: "CHANGE_ACTIVE_TAB"
};

module.exports = tabsConstants;