/**
 * Created by urunzl on 22.7.2016.
 */


var languageConstants = {
  SWITCH_LANGUAGE: "SWITCH_LANGUAGE",
};

module.exports = languageConstants;
