/**
 * Created by urunzl on 20.1.2017.
 */
var helpConstants = {
    SET_RENDERING: "SET_RENDERING"
};

module.exports = helpConstants;
