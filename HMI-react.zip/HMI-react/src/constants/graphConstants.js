/**
 * Created by Lukáš on 6/6/2016.
 */
var graphConstants = {
  CHANGE_VALUES: "CHANGE_VALUES",
  REFRESH_ITEM: "REFRESH_ITEM",
  GET_VALUES: "GET_VALUES"
};

module.exports = graphConstants;
