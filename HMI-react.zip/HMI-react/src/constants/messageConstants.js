/**
 * Created by urunzl on 20.1.2017.
 */
var serverConstants = {
    SHOW_MESSAGE: "SHOW_MESSAGE",
    HIDE_MESSAGE: "HIDE_MESSAGE"
};

module.exports = serverConstants;