/**
 * Created by urunzl on 8.2.2017.
 */
//components
import React, { Component } from 'react';

class Graphs extends Component{
    constructor(props){
        super(props);
        this.state = {

        }
    }

    render(){
        return(
            <div>hh</div>
        )
    }
}

export default Graphs;