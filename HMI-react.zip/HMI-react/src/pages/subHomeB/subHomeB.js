/**
 * Created by urunzl on 3.8.2016.
 */
import React from 'react';
import Page from '../../component/Page/Page'


class SubMenuB extends React.Component {
    render(){
        return(
            <Page>
                <div className="layout horizontal-big start">
                    <div className="layout vertical third-column">
                        <div className="layout vertical start">
                            subHomeB
                        </div>
                    </div>
                </div>
            </Page>
        )
    }
}

export default SubMenuB;