/**
 * Created by urunzl on 3.8.2016.
 */
/**
 * Created by urunzl on 3.8.2016.
 */
import React from 'react';
import Page from '../../component/Page/Page'


class SubMenuA extends React.Component {
    render(){
        return(
            <Page>
                <div className="layout horizontal-big start">
                    <div className="layout vertical third-column">
                        <div className="layout vertical start">
                            subHomeA
                        </div>
                    </div>
                </div>
            </Page>
        )
    }
}

export default SubMenuA;