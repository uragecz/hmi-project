module.exports = {
	"ghostMode": false
}